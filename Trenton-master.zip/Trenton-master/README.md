# Perry High School CS Blank Website Template

To create your own site:

1. Change the repository name to _your_username_.
2. Upload an index.html file to show the world.
